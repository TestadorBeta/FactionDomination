<?php

namespace FactionDomination;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;
use pocketmine\player\Player;
use pocketmine\scheduler\Task;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\Position;
use pocketmine\entity\object\ArmorStand;

class Main extends PluginBase implements Listener{
    /** @var Config */
    private $factions;
    /** @var Config */
    private $invitations;
    /** @var Config */
    private $cooldowns;
    /** @var array */
    private $captureState = [];
    /** @var array */
    private $holograms = []; // runtime mapping faction:point -> armorstand reference

    public function onEnable(): void{
        @mkdir($this->getDataFolder());
        $this->factions = new Config($this->getDataFolder() . "factions.yml", Config::YAML, []);
        $this->invitations = new Config($this->getDataFolder() . "invites.yml", Config::YAML, []);
        $this->cooldowns = new Config($this->getDataFolder() . "cooldowns.yml", Config::YAML, []);
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        // schedule the domination/particles task every second
        $this->getScheduler()->scheduleRepeatingTask(new class($this) extends Task{
            private $plugin;
            public function __construct(Main $plugin){ $this->plugin = $plugin; }
            public function onRun(int $currentTick): void{
                $this->plugin->tickCaptures();
                $this->plugin->tickParticles();
            }
        }, 20);
        // respawn holograms for saved points
        foreach($this->factions->getAll() as $name => $data){
            if(!empty($data['points'])){
                foreach($data['points'] as $i => $pt){
                    if(is_array($pt)){
                        $this->spawnHologram($name, (int)$i, $pt);
                    }
                }
            }
        }
        $this->getLogger()->info("FactionDomination v1.2 ativado. Hologramas restaurados.");
    }

    public function onDisable(): void{
        // despawn holograms
        foreach($this->holograms as $key => $as){
            try{ $as->close(); }catch(\Throwable $e){}
        }
        $this->factions->save();
        $this->invitations->save();
        $this->cooldowns->save();
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool{
        if(strtolower($command->getName()) !== 'f') return false;
        if(count($args) === 0){
            $sender->sendMessage(TF::YELLOW . "Uso: /f <create|invite|join|members|setpoint|claim|info>");
            return true;
        }
        $sub = strtolower(array_shift($args));
        switch($sub){
            case 'create': return $this->cmdCreate($sender, $args);
            case 'invite': return $this->cmdInvite($sender, $args);
            case 'join': return $this->cmdJoin($sender, $args);
            case 'members': return $this->cmdMembers($sender, $args);
            case 'setpoint': return $this->cmdSetPoint($sender, $args);
            case 'claim': return $this->cmdClaim($sender, $args);
            case 'info': return $this->cmdInfo($sender, $args);
            case 'removepoint': return $this->cmdRemovePoint($sender, $args);
            default: $sender->sendMessage(TF::RED . "Subcomando desconhecido."); return true;
        }
    }

    private function cmdCreate(CommandSender $sender, array $args): bool{
        if(!$sender instanceof Player){ $sender->sendMessage("Use no jogo"); return true; }
        if(count($args) < 1){ $sender->sendMessage(TF::YELLOW . "Uso: /f create <nome>"); return true; }
        $name = implode(' ', $args);
        if($this->factions->exists($name)){
            $sender->sendMessage(TF::RED . "Já existe uma facção com esse nome.");
            return true;
        }
        $this->factions->set($name, [
            'leader' => $sender->getName(),
            'members' => [$sender->getName()],
            'points' => [],
            'captured' => [false, false, false],
        ]);
        $this->factions->save();
        $sender->sendMessage(TF::GREEN . "Facção '$name' criada. Você é o líder.");
        return true;
    }

    private function cmdInvite(CommandSender $sender, array $args): bool{
        if(!$sender instanceof Player){ $sender->sendMessage("Use no jogo"); return true; }
        if(count($args) < 2){ $sender->sendMessage(TF::YELLOW . "Uso: /f invite <facção> <jogador>"); return true; }
        $faction = $args[0]; $playerName = $args[1];
        if(!$this->factions->exists($faction)){ $sender->sendMessage(TF::RED . "Facção não existe."); return true; }
        $data = $this->factions->get($faction);
        if($data['leader'] !== $sender->getName()){ $sender->sendMessage(TF::RED . "Apenas o líder pode convidar."); return true; }
        $inv = $this->invitations->get($playerName, []);
        $inv[] = $faction;
        $this->invitations->set($playerName, array_unique($inv));
        $this->invitations->save();
        $sender->sendMessage(TF::GREEN . "Convite enviado para $playerName.");
        $p = $this->getServer()->getPlayerExact($playerName);
        if($p instanceof Player){ $p->sendMessage(TF::AQUA . "Você foi convidado para entrar na facção $faction. Use /f join $faction para aceitar."); }
        return true;
    }

    private function cmdJoin(CommandSender $sender, array $args): bool{
        if(!$sender instanceof Player){ $sender->sendMessage("Use no jogo"); return true; }
        if(count($args) < 1){ $sender->sendMessage(TF::YELLOW . "Uso: /f join <facção>"); return true; }
        $faction = $args[0];
        if(!$this->factions->exists($faction)){ $sender->sendMessage(TF::RED . "Facção não existe."); return true; }
        $inv = $this->invitations->get($sender->getName(), []);
        if(!in_array($faction, $inv)){
            $sender->sendMessage(TF::RED . "Você não foi convidado para essa facção.");
            return true;
        }
        $data = $this->factions->get($faction);
        $data['members'][] = $sender->getName();
        $this->factions->set($faction, $data);
        $this->factions->save();
        $inv = array_filter($inv, fn($v)=> $v !== $faction);
        $this->invitations->set($sender->getName(), array_values($inv));
        $this->invitations->save();
        $sender->sendMessage(TF::GREEN . "Você entrou na facção $faction.");
        return true;
    }

    private function cmdMembers(CommandSender $sender, array $args): bool{
        if(count($args) < 1){ $sender->sendMessage(TF::YELLOW . "Uso: /f members <facção>"); return true; }
        $faction = $args[0];
        if(!$this->factions->exists($faction)){ $sender->sendMessage(TF::RED . "Facção não existe."); return true; }
        $data = $this->factions->get($faction);
        $sender->sendMessage(TF::GOLD . "Membros de $faction: " . implode(', ', $data['members']));
        return true;
    }

    private function cmdSetPoint(CommandSender $sender, array $args): bool{
        if(!$sender instanceof Player){ $sender->sendMessage("Use no jogo"); return true; }
        if(count($args) < 2){ $sender->sendMessage(TF::YELLOW . "Uso: /f setpoint <facção> <1-3>"); return true; }
        $faction = $args[0]; $idx = (int)$args[1] - 1;
        if(!$this->factions->exists($faction)){ $sender->sendMessage(TF::RED . "Facção não existe."); return true; }
        $data = $this->factions->get($faction);
        if($data['leader'] !== $sender->getName()){ $sender->sendMessage(TF::RED . "Apenas o líder pode definir pontos."); return true; }
        if($idx < 0 || $idx > 2){ $sender->sendMessage(TF::RED . "Escolha um índice entre 1 e 3."); return true; }
        $pos = $sender->getPosition();
        $point = ['x' => (int)$pos->getX(), 'y' => (int)$pos->getY(), 'z' => (int)$pos->getZ(), 'level' => $pos->getWorld()->getFolderName()];
        $points = $data['points'];
        $points[$idx] = $point;
        # validate distances
        $coords = [];
        foreach($points as $p){ if(is_array($p)) $coords[] = [$p['x'],$p['y'],$p['z']]; }
        $valid = true;
        foreach($coords as $a){
            foreach($coords as $b){
                if($a === $b) continue;
                $dist = sqrt(pow($a[0]-$b[0],2)+pow($a[1]-$b[1],2)+pow($a[2]-$b[2],2));
                if($dist > 120) $valid = false;
            }
        }
        if(!$valid){ $sender->sendMessage(TF::RED . "Distância entre pontos deve ser no máximo 120 blocos entre si."); return true; }
        $data['points'] = $points;
        $this->factions->set($faction, $data);
        $this->factions->save();
        # spawn/update hologram at this point
        $this->spawnHologram($faction, $idx, $point);
        $sender->sendMessage(TF::GREEN . "Ponto " . ($idx+1) . " definido para a facção $faction.");
        return true;
    }

    private function cmdClaim(CommandSender $sender, array $args): bool{
        if(!$sender instanceof Player){ $sender->sendMessage("Use no jogo"); return true; }
        if(count($args) < 1){ $sender->sendMessage(TF::YELLOW . "Uso: /f claim <facção>"); return true; }
        $faction = $args[0];
        if(!$this->factions->exists($faction)){ $sender->sendMessage(TF::RED . "Facção não existe."); return true; }
        $data = $this->factions->get($faction);
        if($data['leader'] !== $sender->getName()){ $sender->sendMessage(TF::RED . "Apenas o líder pode reivindicar território."); return true; }
        if(count($data['points']) < 3){ $sender->sendMessage(TF::RED . "Defina os 3 pontos antes de claimar."); return true; }
        for($i=0;$i<3;$i++){ if(!isset($data['points'][$i])){ $sender->sendMessage(TF::RED . "Os 3 pontos precisam estar definidos."); return true; }}
        $data['captured'] = [false,false,false];
        $this->factions->set($faction, $data);
        $this->factions->save();
        for($i=0;$i<3;$i++) $this->spawnHologram($faction, $i, $data['points'][$i]);
        $sender->sendMessage(TF::GREEN . "Território reivindicado com sucesso para $faction.");
        return true;
    }

    private function cmdRemovePoint(CommandSender $sender, array $args): bool{
        if(!$sender instanceof Player){ $sender->sendMessage("Use no jogo"); return true; }
        if(count($args) < 2){ $sender->sendMessage(TF::YELLOW . "Uso: /f removepoint <facção> <1-3>"); return true; }
        $faction = $args[0]; $idx = (int)$args[1] - 1;
        if(!$this->factions->exists($faction)){ $sender->sendMessage(TF::RED . "Facção não existe."); return true; }
        $data = $this->factions->get($faction);
        if($data['leader'] !== $sender->getName()){ $sender->sendMessage(TF::RED . "Apenas o líder pode remover pontos."); return true; }
        if(isset($data['points'][$idx])){
            unset($data['points'][$idx]);
            $data['points'] = array_values($data['points']);
            $data['captured'][$idx] = false;
            $this->factions->set($faction, $data);
            $this->factions->save();
            $this->despawnHologramKey($faction, $idx);
            $sender->sendMessage(TF::GREEN . "Ponto " . ($idx+1) . " removido.");
        }else{
            $sender->sendMessage(TF::RED . "Ponto não existe.");
        }
        return true;
    }

    private function cmdInfo(CommandSender $sender, array $args): bool{
        if(count($args) < 1){ $sender->sendMessage(TF::YELLOW . "Uso: /f info <facção>"); return true; }
        $faction = $args[0];
        if(!$this->factions->exists($faction)){ $sender->sendMessage(TF::RED . "Facção não existe."); return true; }
        $data = $this->factions->get($faction);
        $sender->sendMessage(TF::GOLD . "Facção: $faction\nLíder: {$data['leader']}\nMembros: " . implode(', ', $data['members']));
        for($i=0;$i<3;$i++){
            if(isset($data['points'][$i])){
                $p = $data['points'][$i];
                $cap = $data['captured'][$i] ? 'SIM' : 'NÃO';
                $sender->sendMessage(TF::GRAY . "Ponto " . ($i+1) . ": ({$p['x']},{$p['y']},{$p['z']}) Capturado: $cap");
            }
        }
        return true;
    }

    # Hologram + particles + capture logic are implemented in this file. Note: depending on your PocketMine fork
    # some class names may differ (entity/particle). If you encounter errors in server logs, send me the trace and
    # I will adapt the code for your build.
}
